# survival-guide
UP Epsilon Chi Fraternity Survival Guide Mobile Application

Android Version of Survival Guide App 2019

**Use Android Studio Java to develop
